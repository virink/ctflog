﻿<?php
header("Content-Type:text/html;charset=utf-8");
include_once("config.php");
session_start();
if(!isset($_SESSION['username'])) {
		die('Login First');
	}
if (isset($_POST['captcha']) && isset($_POST['duihuanma'])) {
	if(!(substr(md5($_POST['captcha']), 0, 4)===$_SESSION['captcha']))
		die('<center><p>captcha not right</p></center>');
    $sql = "select $secret from users where user='${_SESSION['username']}'";
    #echo $sql;
    $result=mysql_query($sql);
    $row = mysql_fetch_array($result);
    
}

$captcha= getCaptcha(4);
$_SESSION['captcha'] = $captcha;
function getCaptcha($length){
	$str = null;
	$strPol = "0123456789abcdef";
	$max = strlen($strPol)-1;

	for($i=0;$i<$length;$i++){
		$str.=$strPol[rand(0,$max)];
	}
	return $str;
}



?>

<!DOCTYPE html>
<html>
<head>
   <title>Profile</title>
   <link href="static/bootstrap.min.css" rel="stylesheet">
   <script src="static/jquery.min.js"></script>
   <script src="static/bootstrap.min.js"></script>
</head>
<body>
    <center>
	<div class="container" style="margin-top:100px">
		<h3>Hi <?php echo $_SESSION['username'];?></h3><br>
        <form method='post'>
        <p>请输入您的36位兑换码: <br><input name='duihuanma' type='text'></p>
        <p>captcha: <br><input name='captcha' type='text'></p>
        <?php echo  "<br><center>substr(md5(captcha), 0, 4)=".$captcha."</center><br>";?>
        <input type="submit" value="Submit" />
        <?php
        if (isset($_POST['duihuanma'])){
            if ($row[$secret]===$_POST['duihuanma']){
                echo "<br><center>".$flag."</center>";
            }else{
                echo "<center>flag兑换码不正确</center>";
            }
        }
        ?>
        </form>
	</div>
    </center>
</body>
</html>