<?php 
    include("config.php");
    function is_exists($username){
        $sql = "select user from users where user = '$username'";
        $result = mysql_query($sql);
        if ($row = mysql_fetch_array($result)){
            return True;
        }else{
            return False;
        }
    }
	if($_POST['username'] && $_POST['password']) {
		$username = $_POST['username'];
		$password = $_POST['password'];

		if(strlen($username) < 3 or preg_match("|'|",$username) or preg_match("|\\\\|",$username)) 
			die('Invalid user name');

		if(strlen($password) < 3 ) 
			die('Invalid password');
		if(!is_exists($username)) {
            $sql = "insert into users(user,pass) values('$username',md5('$password'))";
            mysql_query($sql);
			echo '<center><h1>Register OK!<a href="index.php">Please Login</a></h1></center>';
		}
		else {
			die('<center><h1>User name Already Exists</h1></center>');
		}
	}
	else {
?>
<!DOCTYPE html>
<html>
<head>
   <title>REGISETER</title>
   <link href="static/bootstrap.min.css" rel="stylesheet">
   <script src="static/jquery.min.js"></script>
   <script src="static/bootstrap.min.js"></script>
</head>
<body>
	<div class="container" style="margin-top:100px">  
		<form action="register.php" method="post" class="well" style="width:220px;margin:0px auto;"> 
			<img src="static/piapiapia.gif" class="img-memeda " style="width:180px;margin:0px auto;">
			<h3>Register</h3>
			<label>Username:</label>
			<input type="text" name="username" style="height:30px"class="span3"/>
			<label>Password:</label>
			<input type="password" name="password" style="height:30px" class="span3">

			<button type="submit" class="btn btn-primary">REGISTER</button>
		</form>
	</div>
</body>
</html>
<?php
	}
?>
