<?php
	$host = '127.0.0.1';
	$user= 'ctf_shenji';
	$pass = 'ctf_shenji';
	$db = 'shenji';
    $conn = mysql_connect($host,$user,$pass);
    mysql_query("use $db");
    $secret="*****************";
    $flag="flag{*************}";
?>
