<?php
/*
CREATE TABLE `users` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `user` varchar(20) DEFAULT NULL,
  `pass` varchar(32) DEFAULT NULL,
  `$secret` varchar(36) DEFAULT NULL,
  `count` int(3) DEFAULT NULL,
  PRIMARY KEY (`id`)
)
*/
header("Content-Type:text/html;charset=utf-8");
    session_start();
	include_once('config.php');
	if(empty($_SESSION['username'])) {
		die('Login First!');	
	}
	$username = $_SESSION['username'];
    change($secret);
    function duihuanma_product()
    {
        $string = "1234567890abcdefghijklmnopqrstuvwxyz";
        return str_shuffle($string);
    }
    
    function change($secret)
    {
        global $username,$row;
        $duihuanma = duihuanma_product();
        $row = mysql_fetch_array(mysql_query("select * from users where user='$username'"));
        $count = $row['count'];
        if (!$row[$secret]){
            mysql_query("update users set $secret='{$duihuanma}' where user='$username'");
        }
        if($row['count'] == 140)
        {
            
            if(mysql_query("update users set $secret='{$duihuanma}' where user='$username';"))
            {
                mysql_query("update users set count=0 where user='$username';");
                die("<center><br><h3>尝试次数过多，兑换码已经重置</h3></center>");
            }
            return $duihuanma;
        }
        else
        {
        mysql_query("update users set count=({$row['count']} + 1) where user='$username';");
        }
        return $row[$secret];
    }
?>
<!DOCTYPE html>
<html>
<head>
   <title>Profile</title>
   <link href="static/bootstrap.min.css" rel="stylesheet">
   <script src="static/jquery.min.js"></script>
   <script src="static/bootstrap.min.js"></script>
</head>
<body>
    <center>
	<div class="container" style="margin-top:100px">
        <?php
            $id=$_GET['id']?$_GET['id']:0;
            if(preg_match("#\.#",$id) or preg_match("#_#",$id) or preg_match("#\(#",$id) or preg_match("#\)#",$id))  
                die('<h3>danger character dectected</h3>');
            $sql = "select * from users where id=$id";
            $result = mysql_query($sql);
            $rownew = @mysql_fetch_array($result);
            $rownew['user']=$rownew['user']?$rownew['user']:"noman";
        ?>
		<h3>This is <?php echo $rownew['user'];?> page,您已经访问<?php echo $row['count']+1;?>次</h3><br>
        <?php
            if ($rownew['user']==='admin'){
                echo "<br><h3>good job,hint: thisissourcecode.zip</h3>";
            }
        
        ?>
	</div>
    </center>
</body>
</html>

