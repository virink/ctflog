<?php

date_default_timezone_set('PRC');
$var_name_3 = array('rewrite' => array(str_rot13('n' . ('qzv' . ('a' . ('/va' . ('qrk.' . 'ugzy'))))) => 'admin/main/index', str_rot13('n' . ('qzva/<' . ('p' . ('>_<n>.' . 'ugzy')))) => 'admin/<c>/<a>', '<m>/<c>/<a>' => '<m>/<c>/<a>', '<c>/<a>' => '<c>/<a>', '/' => 'main/index'));
$config = array(
	'hardphp' => array('debug' => 0,
		'mysql' => array(
			'MYSQL_HOST' => '127.0.0.1',
			'MYSQL_PORT' => '3306',
			'MYSQL_NAME' => 'root',
			'MYSQL_DB' => 'hardphp',
			'MYSQL_PASS' => '123456',
			'MYSQL_CHARSET' => 'utf8',
		),
	),
	str_rot13('fc' . ('r' . ('r' . ('qc' . ('uc' . ('.' . 'pbz')))))) => array('debug' => 0 + (0 - 0) + (0 + (0 - 0) - (0 + (0 - 0))), 'mysql' => array()),
);
if (empty($config['hardphp'])) {
	die(str_rot13('�' . ('��置域名�' . ('��正确，�' . ('�' . ('确认uneqcu' . ('c的配置是' . '否存在！')))))));
}
return $config['hardphp'] + $var_name_3;