<?php 
 class Dbsession extends Model{public $table_name = "dbsession";}