<?php
class Log extends Model {public $table_name = "log";}