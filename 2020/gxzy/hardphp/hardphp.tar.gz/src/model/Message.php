<?php
class Message extends Model {public $table_name = "msg";}