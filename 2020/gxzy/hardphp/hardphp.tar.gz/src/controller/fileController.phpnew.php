<?php
class FileController extends BaseController {
	function actionIndex() {
		$this->{'jump'}('/main/index');
	}
	public function actionUpload() {
		if (!isset($_SESSION['data'])) {
			$this->{'jump'}('/user/login');
			return;
		}

		$var_name_3 = unserialize([$_SESSION['data'], ['allowed_classes' => ['Session']]]);
		$ip = arg('HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR');
		$ua = arg('HTTP_USER_AGENT');
		if (!$var_name_3->isAccountSec($ip, $ua)) {
			echo str_rot13('<fpevcg>nyreg(\'lbhe pbbxvr zl or fgrnyrq ol unpxre!\');
            </fpevcg>');
			session_destroy();
			$this->jump('/user/login');
			return;
		}
		if (empty($_FILES['upfile'])) {
			echo str_rot13('<fpevcg>nyreg("Hcybnq svyr rzcgl!")</fpevcg>');
			$this->jump('/main/index');
			return;
		}
		$var_name_14 = new Upload($_FILES['upfile'], $this);
		$var_name_14->upload();
	}
}