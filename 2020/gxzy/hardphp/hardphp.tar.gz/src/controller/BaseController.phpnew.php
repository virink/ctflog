<?php
class BaseController extends Controller {
	public $layout = "layout.html";
	function init() {
		ini_set('session.save_handler', 'user');
		$var_name_3 = new MySessionHandler();
		session_set_save_handler($var_name_3, 1);
		session_start();
		header('Content-type: text/html; charset=utf-8');
	}

	function tips($var_name_10, $var_name_11) {
		$var_name_11 = "location.href=\"{$var_name_11}\";";
		echo "<html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"><script>function sptips(){alert(\"{$var_name_10}\");{$var_name_11}</script></head><body onload=\"sptips()\"></body></html>";
		exit;
	}
	function jump($var_name_11, $var_name_12 = 0) {
		echo "<html><head><meta http-equiv='refresh' content='{$var_name_12};url={$var_name_11}'></head><body></body></html>";
		exit;
	}
	public static function err404($var_name_13, $var_name_14, $var_name_15, $var_name_10) {
		header('HTTP/1.0 404 Not Found');
		exit;
	}
}