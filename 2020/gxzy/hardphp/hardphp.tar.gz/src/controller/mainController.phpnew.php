<?php
class MainController extends BaseController {
	function actionIndex() {
		if (isset($_SESSION['data'])) {
			$var_name_3 = unserialize([$_SESSION['data'], ['allowed_classes' => ['Session']]]);
			$ip = arg('HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR');
			$ua = arg('HTTP_USER_AGENT');
			$this->now = $var_name_3::getTime(time());
			if ($var_name_3->isAccountSec($ip, $ua)) {
				$var_name_14 = $var_name_3->getUserInfo();
				$this->username = $_SESSION['username'];
				$this->loginTime = $var_name_14[1];
				$Users = new User();
				$var_name_16 = $Users->query("SELECT picture FROM `{$Users->table_name}` where `id`='{$var_name_3}'");
				if (!empty($var_name_16)) {
					$this->picSrc = $var_name_16[0]['picture'];
				} else {
					$this->picSrc = str_rot13('/vzt/cvp.wct');
				}
			} else {
				echo str_rot13('<fpevcg>nyreg(\'lbhe pbbxvr zl or fgrnyrq ol unpxre!\');</fpevcg>');
				session_destroy();
				$this->{'jump'}('/user/login');
			}
		} else {
			$this->jump('/user/login');
			return;
		}
	}
	public function actionMessage() {
		if (!isset($_SESSION['data'])) {
			$this->jump('/user/login');
			return;
		}
		$var_name_3 = unserialize([$_SESSION['data'], ['allowed_classes' => ['Session']]]);
		$ip = arg('HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR');
		$ua = arg('HTTP_USER_AGENT');
		$this->now = $var_name_3::getTime(time());
		if (!$var_name_3->isAccountSec($ip, $ua)) {
			echo str_rot13('<fpevcg>nyreg(\'lbhe pbbxvr zl or fgrnyrq ol unpxre!\');</fpevcg>');
			session_destroy();
			$this->{'jump'}('/user/login');
			return;
		}
		$messages = array();
		$Msgs = new Message();
		$Users = new User();
		$var_name_16 = $Msgs->query("SELECT * FROM `{$Msgs->table_name}` order by `id` desc  limit 0,100");
		foreach ($var_name_16 as $var_name_33 => $var_name_34) {
			$var_name_35 = $var_name_34['userid'];
			$var_name_14 = $Users->query("SELECT * FROM `{$Users->table_name}` WHERE `id`='{$var_name_35}'");
			if (!empty($var_name_14)) {
				$username = $var_name_14[0]['username'];
				$var_name_37 = $var_name_14[0]['picture'];
				array_push($messages, array('username' => $username, 'message' => $var_name_34['content']));
			}
		}
		$this->messages = $messages;
	}
	public function actionPost() {
		if (!isset($_SESSION['data'])) {
			$this->{'jump'}('/user/login');
			return;
		}
		$var_name_3 = unserialize([$_SESSION['data'], ['allowed_classes' => ['Session']]]);
		$ip = arg('HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR');
		$ua = arg('HTTP_USER_AGENT');
		$this->now = $var_name_3::getTime(time());
		if (!$var_name_3->isAccountSec($ip, $ua)) {
			echo str_rot13('<fpevcg>nyreg(\'lbhe pbbxvr zl or fgrnyrq ol unpxre!\');</fpevcg>');
			session_destroy();
			$this->{'jump'}('/user/login');
			return;
		}
		if ($_POST) {
			$var_name_32 = new Message();
			$var_name_16 = $var_name_32->create(['userid' => (string) $var_name_3, 'content' => arg('msg')]);
			$this->jump('/main/Message');
		}
	}
}