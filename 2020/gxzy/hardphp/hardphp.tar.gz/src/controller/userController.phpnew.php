<?php
class userController extends BaseController {

	function actionIndex() {
		$this->{'jump'}('/user/login');
	}

	function actionLoginOut() {
		session_destroy();
		$this->{'jump'}('/user/login');
	}

	function actionLogin() {
		if ($_POST) {
			$username = arg('username');
			$password = arg('password');
			$ip = arg('HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR');
			$ua = arg('HTTP_USER_AGENT');
			if (empty($username) || empty($password)) {
				echo str_rot13('<fpevcg>nyreg(\'Hfreanzr be cnffjbeq vf rzcgl.\')<' . '/fpevcg>');
			} else {
				$Users = new User();
				$password = md5($password);
				$result = $Users->query("SELECT * FROM `{$Users->table_name}` where `username`='{$username}' AND `password`='{$password}'");
				if (empty($result) || $result[0]['password'] !== $password) {
					echo str_rot13('<fpevcg>nyreg(\'Hfreanzr be cnffjbeq vf reebe.\')</fpevcg>');
				} else {
					$var_name_23 = new Session($result[0]['id'], time(), $ip, $ua);
					$_SESSION['data'] = serialize($var_name_23);
					$_SESSION['username'] = $username;
					$this->{'jump'}('/main/index');
				}
			}
		}
	}
	function actionRegister() {
		if ($_POST) {
			$username = arg('username');
			$password = arg('password');
			if (empty($username) || empty($password)) {
				echo str_rot13('<fpevcg>nyreg(\'Hfreanzr be cnffjbeq vf rzcgl.\')<' . '/fpevcg>');
			} else {
				$password = md5($password);
				$Users = new User();
				$result = $Users->query("SELECT * FROM `{$Users->table_name}` WHERE `username` ='{$username}'");
				if (!empty($result)) {
					echo str_rot13('<fpevcg>nyreg(\'Hfreanzr vf ertvfgrerq!.\')</fpevcg>');
				} else {
					$result = $Users->create(['username' => $username, 'password' => $password, 'picture' => str_rot13('/vzt/cvp.wct')]);
					if (!$result) {
						echo str_rot13('<fpevcg>nyreg(\'fbzrguvat reebe. ertvfgre svnvrq!\'</fpevcg>');
					} else {
						$this->jump('/user/login');
					}
				}
			}
		}
	}
}