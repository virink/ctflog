<?php
class MySessionHandler implements SessionHandlerInterface {
	private $savepath;
	private $dbsession;
	public function open($var_name_1, $var_name_2) {
		$this->dbsession = new DbSession();
        $this->gc(ini_get('session.gc_maxlifetime'));
		return 1;
	}
	public function close() {
		return 1;
	}
	public function read($sessid) {
		$var_name_6 = $this->dbsession->query("SELECT * FROM `{$this->dbsession->table_name}` where `sessionid` = '{$sessid}'");
		if (empty($var_name_6)) {
			return serialize([]);
		} else {
			return (string) @$var_name_6[0]['data'];
		}
	}
	public function write($sessid, $data) {
		$data = str_replace("\x00", '\0', $data);
		$time = time();
		$var_name_6 = $this->dbsession->query("SELECT * FROM `{$this->dbsession->table_name}` where `sessionid` = '{$sessid}' ");
		if ($var_name_6) {
			$this->dbsession->execute("UPDATE `{$this->dbsession->table_name}` SET `data` = '{$data}',`lastvisit` = '{$time}' where `sessionid` = '{$sessid}'");
		} else {
			$var_name_6 = $this->dbsession->create(['data' => $data, 'sessionid' => $sessid, 'lastvisit' => $time]);
		}return 1;
	}
    public function destroy($sessid) {
		$var_name_6 = $this->dbsession->execute("DELETE FROM `{$this->dbsession->table_name}` where `sessionid`='{$sessid}'");
		return $var_name_6;
	}
    public function gc($var_name_15) {
		$var_name_18 = time()
		$var_name_6 = $this->dbsession->execute("DELETE FROM `{$this->dbsession->table_name}` where ({$var_name_15}+`lastvisit`)<{$var_name_18}");
		if ($var_name_6) {
			return 1;
		}return '';
	}}