	<?php
class Upload {
	protected $upfile;
	protected $controller;
	protected $userId;
	protected $user;
	protected $savePath = "img" . DS . "upload" . DS;

	function __construct($upfile, $controller) {
		$this->upfile = $upfile;
		$this->controller = $controller;
		$this->user = new User();
		$obj = unserialize([$_SESSION['data'], ['allowed_classes' => ['Session']]]);
		$this->userId = $obj->getUserInfo()[0];
	}
	public function write($data, $name) {
		if ($this->waf($data)) {
			return file_put_contents($name, $data);
		}
		return '';
	}
	public function waf($data) {
		// <?=? >
		return strpos($data, '<?php') === '';
	}
	public function upload() {
		if ($this->upfile['error'] != UPLOAD_ERR_OK) {
			echo str_rot13('<fpevcg>nyreg("hcybnq svyr reebe!")</fpevcg>');
			$this->controller->jump(str_rot13('/znva/vaqrk'));
			return;
		}
		if ($this->upfile['size'] > 102400) {
			echo str_rot13('<fpevcg>nyreg("hcybnq svyr gbb ovt!")</fpevcg>');
			$this->controller->jump(str_rot13('/znva/vaqrk'));
			return;
		}
		$name = $this->upfile['name'];
		$pathinfo = pathinfo($name);
		$ext = isset($pathinfo['extension']) ? $pathinfo['extension'] : 'png';
		if (!in_array($ext, ['jpg', 'png', 'bmp'])) {
			$ext = 'png';
		}
		$ext = addslashes($ext);
		$this->save($this->upfile['tmp_name'], $this->randomStr() . '.' . $ext);
	}
	public function save($tmp_name, $dstname) {
		$dst = APP_DIR . DS . $this->savePath . $dstname;
		$data = file_get_contents($tmp_name);
		if ($this->write($data, $dst)) {
			$var_name_27 = DS . $this->savePath . $dstname;
			$var_name_28 = $this->user->execute("UPDATE `{$this->user->table_name}` set `picture`='{$var_name_27}' where `id`='{$this->userId}'");
			if ($var_name_28) {
				echo str_rot13('<' . ('fpevcg>' . ('nyreg("H' . ('cybnq sv' . ('yr fhppr' . ('ff!")</f' . 'pevcg>'))))));
			} else {
				echo str_rot13('<' . ('fpevcg>n' . ('y' . ('reg("Hcy' . ('b' . ('nq svyr ' . ('reebe!")<' . '/fpevcg>')))))));
			}
			$this->controller->jump(str_rot13('/znva/vaqrk'));
			return;
		} else {
			echo str_rot13('<fpev' . ('c' . ('g>ny' . ('r' . ('eg("' . ('Hcybn' . ('q' . (' svy' . ('r' . (' Ree' . ('b' . ('e!")' . '</fpevcg>'))))))))))));
			$this->{'controller'}->{'jump'}(str_rot13('/znva/vaqrk'));return;
		}
	}
	private function randomStr($n = 32) {
		$tables = 'abcdefghijklmnopqrstuvwxyz0123456789';
		$res = '';
		for ($i = 0; $i < $n; $i++) {
			$res .= $tables[mt_rand(0, strlen($tables) - 1)];
		}
		return $res;
	}
	public function __destruct() {
		if (is_file($this->upfile['tmp_name'])) {
			unlink($this->upfile['tmp_name']);
		}
	}
}