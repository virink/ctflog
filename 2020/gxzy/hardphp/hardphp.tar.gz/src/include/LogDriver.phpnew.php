<?php
class LogDriver extends Model {
	function __construct() {
		$this->log = new Log();
	}
	function save($time, $msg) {
		return $this->log->create([
			'time' => $time,
			'type' => $msg['type'],
			'data' => mysqli_escape_string($this->log->db, $msg['data'])]
		);
	}
}