<?php
class Logger {
	protected $err = [];
	protected $handle;
	public function __construct() {
		$this->handle = new LogDriver();
	}
	public function add($data, $type = null) {
		$this->err[time()] = ['data' => $data, 'type' => $type];
	}
	public function __destruct() {
		if (count($this->err)) {
			foreach ($this->err as $time => $data) {
				$this->handle->save($time, $data);
			}
		}
	}
}