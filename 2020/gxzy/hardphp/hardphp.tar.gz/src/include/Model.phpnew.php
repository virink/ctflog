<?php
class Model {
	public $page;
	public $table_name;
	public $db;
	protected $sql = array();
	public function __construct($var_name_1 = null) {
		if ($var_name_1) {
			$this->table_name = $var_name_1;
		}

		$this->db = $this->dbInstance($GLOBALS['mysql'], 'master');
	}

	public function dumpSql() {
		return $this->sql;
	}

	public function pager($page, $pageSize = 10, $scope = 10, $total) {
		$this->page = null;
		if ($total > $pageSize) {
			$total_page = ceil($total / $pageSize);
			$page = min(intval(max($page, 1)), $total_page);
			$this->page = array(
				'total_count' => $total,
				'page_size' => $pageSize,
				'total_page' => $total_page,
				'first_page' => 1,
				'prev_page' => ((1 == $page) ? 1 : ($page - 1)),
				'next_page' => (($page == $total_page) ? $total_page : ($page + 1)),
				'last_page' => $total_page,
				'current_page' => $page,
				'all_pages' => array(),
				'offset' => ($page - 1) * $pageSize,
				'limit' => $pageSize,
			);
			$scope = (int) $scope;
			if ($total_page <= $scope) {
				$this->page['all_pages'] = range(1, $total_page);
			} elseif ($page <= $scope / 2) {
				$this->page['all_pages'] = range(1, $scope);
			} elseif ($page <= $total_page - $scope / 2) {
				$right = $page + (int) ($scope / 2);
				$this->page['all_pages'] = range($right - $scope + 1, $right);
			} else {
				$this->page['all_pages'] = range($total_page - $scope + 1, $total_page);
			}
		}
		return $this->page;
	}
	public function query($sql, $params = array()) {
		return $this->execute($sql, $params, true);
	}
	public function execute($sql, $params = array(), $readonly = false) {
		$this->sql[] = $sql;

		if ($readonly && !empty($GLOBALS['mysql']['MYSQL_SLAVE'])) {
			$slave_key = array_rand($GLOBALS['mysql']['MYSQL_SLAVE']);
			$sth = $this->dbInstance($GLOBALS['mysql']['MYSQL_SLAVE'][$slave_key], 'slave_' . $slave_key)->prepare($sql);
		} else {
			$sth = $this->dbInstance($GLOBALS['mysql'], 'master')->prepare($sql);
		}

		if (is_array($params) && !empty($params)) {
			foreach ($params as $k => &$v) {
				if (is_int($v)) {
					$data_type = PDO::PARAM_INT;
				} elseif (is_bool($v)) {
					$data_type = PDO::PARAM_BOOL;
				} elseif (is_null($v)) {
					$data_type = PDO::PARAM_NULL;
				} else {
					$data_type = PDO::PARAM_STR;
				}
				$sth->bindParam($k, $v, $data_type);
			}
		}

		if ($sth->execute()) {
			return $readonly ? $sth->fetchAll(PDO::FETCH_ASSOC) : $sth->rowCount();
		}

		$err = $sth->errorInfo();
		err('Database SQL: "' . $sql . '", ErrorInfo: ' . $err[2], 1);
	}
	public function dbInstance($db_config, $db_config_key, $force_replace = false) {
		if ($force_replace || empty($GLOBALS['mysql_instances'][$db_config_key])) {
			try {
				if (!class_exists("PDO") || !in_array("mysql", PDO::getAvailableDrivers(), true)) {
					err('Database Err: PDO or PDO_MYSQL doesn\'t exist!');
				}
				$GLOBALS['mysql_instances'][$db_config_key] = new PDO('mysql:dbname=' . $db_config['MYSQL_DB'] . ';host=' . $db_config['MYSQL_HOST'] . ';port=' . $db_config['MYSQL_PORT'], $db_config['MYSQL_USER'], $db_config['MYSQL_PASS'], array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'' . $db_config['MYSQL_CHARSET'] . '\''));
			} catch (PDOException $e) {err('Database Err: ' . $e->getMessage());}
		}
		return $GLOBALS['mysql_instances'][$db_config_key];
	}
	public function lastInsertId() {
		return $this->dbInstance($GLOBALS['mysql'], 'master')->insert_id;
	}
	public function create($datas) {
		$keys = [];
		$values = [];
		foreach ($datas as $key => $value) {
			$keys[] = "`{$key}`";
			$values[] = "'{$value}'";
		}
		$sql = sprintf('INSERT INTO `%s`( %s ) VALUES ( %s )', $this->table_name, implode(',', $keys), implode(',', $values));
		return $this->execute($sql);
	}
}
