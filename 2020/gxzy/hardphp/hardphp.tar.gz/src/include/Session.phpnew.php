<?php
class Session {
	protected $ip;
	protected $userAgent;
	protected $userId;
	protected $loginTime;
	public static $timeFormat = "H:i:s";
	function __construct($userId, $loginTime, $ip = "0.0.0.0", $userAgent = "") {
		$this->userId = $userId;
		$this->ip = $ip;
		$this->loginTime = $loginTime;
		$this->userAgent = md5($userAgent);
	}
	public function getUserInfo() {
		return array(intval($this->userId), date(self::$timeFormat, $this->loginTime));
	}
	public function isAccountSec($ip = "0.0.0.0", $userAgent = "") {
		return $this->ip === $ip && $this->userAgent === md5($userAgent);
	}
	public function __toString() {
		return $this->userId;
	}
	static function getTime($time) {
		return date(self::$timeFormat, $time);
	}
}