<?php
class Controller {
	public $layout;
	public $_auto_display = true;
	protected $_v;
	protected $_data = array();
	public function init() {}
	public function __construct() {
		$this->init();
	}
	public function &__get($var_name_1) {
		return $this->_data[$var_name_1];
	}
	public function __set($var_name_1, $var_name_2) {
		$this->_data[$var_name_1] = $var_name_2;
	}
	public function display($var_name_3, $var_name_4 = false) {
		if (!$this->_v) {
			$var_name_5 = isset($G['view']['compile_dir']) ? $G['view']['compile_dir'] : APP_DIR . DS . 'tmp';
			$this->_v = new View(APP_DIR . DS . 'view', $var_name_5);
		}
		$this->_v->assign(get_object_vars($this));
		$this->_v->assign($this->_data);
		if ($this->layout) {
			$this->_v->assign('__template_file', $var_name_3);
			$var_name_3 = $this->layout;
		}
		$this->_auto_display = '';
		if ($var_name_4) {
			return $this->_v->render($var_name_3);
		} else {
			echo $this->_v->render($var_name_3);
			return '';
		}
	}
}