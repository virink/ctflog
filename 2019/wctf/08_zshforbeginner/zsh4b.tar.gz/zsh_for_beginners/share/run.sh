#!/bin/sh
/usr/sbin/xinetd -dontfork
