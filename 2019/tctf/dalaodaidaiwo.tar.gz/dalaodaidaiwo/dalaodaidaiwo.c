/*
  +----------------------------------------------------------------------+
  | PHP Version 7                                                        |
  +----------------------------------------------------------------------+
  | Copyright (c) 1997-2018 The PHP Group                                |
  +----------------------------------------------------------------------+
  | This source file is subject to version 3.01 of the PHP license,      |
  | that is bundled with this package in the file LICENSE, and is        |
  | available through the world-wide-web at the following url:           |
  | http://www.php.net/license/3_01.txt                                  |
  | If you did not receive a copy of the PHP license and are unable to   |
  | obtain it through the world-wide-web, please send a note to          |
  | license@php.net so we can mail you a copy immediately.               |
  +----------------------------------------------------------------------+
  | Author:                                                              |
  +----------------------------------------------------------------------+
*/

/* $Id$ */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <unistd.h>

#include "php.h"
#include "php_ini.h"
#include "ext/standard/info.h"
#include "php_dalaodaidaiwo.h"


static int le_dalaodaidaiwo;


PHP_FUNCTION(dalaodaidaiwo)
{
	FILE *in;
    char *command;
    size_t command_len;
    zend_string *ret;
    php_stream *stream;

    ZEND_PARSE_PARAMETERS_START(1, 1)
        Z_PARAM_STRING(command, command_len)
    ZEND_PARSE_PARAMETERS_END();

#ifdef PHP_WIN32
    if ((in=VCWD_POPEN(command, "rt"))==NULL) {
#else
    if ((in=VCWD_POPEN(command, "r"))==NULL) {
#endif
        php_error_docref(NULL, E_WARNING, "Unable to execute '%s'", command);
        RETURN_FALSE;
    }

    stream = php_stream_fopen_from_pipe(in, "rb");
    ret = php_stream_copy_to_mem(stream, PHP_STREAM_COPY_ALL, 0);
    php_stream_close(stream);

    if (ret && ZSTR_LEN(ret) > 0) {
        RETVAL_STR(ret);
    }
}

PHP_MINIT_FUNCTION(dalaodaidaiwo)
{
	return SUCCESS;
}

PHP_MSHUTDOWN_FUNCTION(dalaodaidaiwo)
{
	return SUCCESS;
}

PHP_RINIT_FUNCTION(dalaodaidaiwo)
{
#if defined(COMPILE_DL_DALAODAIDAIWO) && defined(ZTS)
	ZEND_TSRMLS_CACHE_UPDATE();
#endif
	return SUCCESS;
}

PHP_RSHUTDOWN_FUNCTION(dalaodaidaiwo)
{
	return SUCCESS;
}

PHP_MINFO_FUNCTION(dalaodaidaiwo)
{
	php_info_print_table_start();
	php_info_print_table_header(2, "dalaodaidaiwo support", "enabled");
	php_info_print_table_end();
}

const zend_function_entry dalaodaidaiwo_functions[] = {
	PHP_FE(dalaodaidaiwo,	NULL)		/* For testing, remove later. */
	PHP_FE_END	/* Must be the last line in dalaodaidaiwo_functions[] */
};

zend_module_entry dalaodaidaiwo_module_entry = {
	STANDARD_MODULE_HEADER,
	"dalaodaidaiwo",
	dalaodaidaiwo_functions,
	PHP_MINIT(dalaodaidaiwo),
	PHP_MSHUTDOWN(dalaodaidaiwo),
	PHP_RINIT(dalaodaidaiwo),		/* Replace with NULL if there's nothing to do at request start */
	PHP_RSHUTDOWN(dalaodaidaiwo),	/* Replace with NULL if there's nothing to do at request end */
	PHP_MINFO(dalaodaidaiwo),
	PHP_DALAODAIDAIWO_VERSION,
	STANDARD_MODULE_PROPERTIES
};

#ifdef COMPILE_DL_DALAODAIDAIWO
#ifdef ZTS
ZEND_TSRMLS_CACHE_DEFINE()
#endif
ZEND_GET_MODULE(dalaodaidaiwo)
#endif

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 * vim600: noet sw=4 ts=4 fdm=marker
 * vim<600: noet sw=4 ts=4
 */
