default_app_config = 'challenge.apps.ChallengeConfig'
