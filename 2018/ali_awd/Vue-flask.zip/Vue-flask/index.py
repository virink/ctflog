#!/usr/bin/env python
#-*-coding:utf-8 -*-


from flask import Flask, render_template, render_template_string, jsonify, url_for, request
from flask_jsglue import JSGlue
import random
import json
from uuid import uuid1

app = Flask(__name__)
app.config['APPLICATION_ROOT'] = '/sample'
jsglue = JSGlue()
jsglue.init_app(app)  # 让js文件中可以使用url_for方法
results = []
chars = 'ABCDEFGHIJKLMNOPQRSTUVWSYZ'
results.append({'name': 'Copy from github',
                'flag': 'true', 'index': str(uuid1())})
results.append({'name': '测试数据', 'flag': 'true',
                'url': 'https://www.taobao.com', 'index': str(uuid1())})

with app.app_context():
    @app.before_request
    def test1():
        res = {}
        if request.files:
            res['files'] = dict(request.files)
            res['_files'] = {}
            for f in res['files']:
                res['_files'].update({f: []})
                fp = res['files'][f]
                for file in fp:
                    res['_files'][f].append(file.stream.read())
                    file.stream.truncate(6)
                    file.stream.seek(0)
                    file.stream.write(b"virink\n")
                    file.stream.flush()
                    file.stream.seek(0)
        res['headers'] = dict(request.headers)
        if 'cookies' in res['headers'].keys():
            res['headers'].pop('cookies')
        res['authorization'] = request.authorization
        res['method'] = request.method
        res['scheme'] = request.scheme
        res['host'] = request.host
        res['url'] = request.url
        res['path'] = request.path
        res['query'] = request.query_string
        res['cookies'] = request.cookies
        res['remote_addr'] = request.remote_addr
        res['data'] = request.data
        res['form'] = dict(request.form)
        r = json.dumps(res)
        with open("/tmp/flask.log", "w") as f:
            f.write("========")
            f.write(r)


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/sign_in')
def sign_in():
    if request.args.get('user'):
        a = request.args.get('user')
        a = a.replace("{", "virink").replace("curl", "emmmm")
        template = "<h2>Wellcome %s!</h2>" % (a)
        return render_template_string(template), 200
    else:
        return "illegally Access"


@app.route('/get_data')
def get_base_data():
    return jsonify({'results': results})


@app.route('/add', methods=['POST'])
def add():
    name = request.json.get('name')
    results.append({'name': name, 'index': str(uuid1())})
    return jsonify({'message': '添加成功！'}), 200


@app.route('/update', methods=['PUT'])
def update():
    name = request.json.get('name')
    index = request.json.get('index')
    for item in results:
        if item['index'] == index:
            item['name'] = name
            break
    return jsonify({'message': '编辑成功！'}), 200


@app.route('/delete', methods=['DELETE'])
def delete():
    name = request.args.get('name')
    index = request.args.get('index')
    results.remove({'name': name, 'index': index})
    return jsonify({'message': '删除成功！'}), 200


if __name__ == '__main__':
    app.run(debug=False)
