<?php

include "common.php";
if ($_FILES["file"]["error"] > 0) {
    echo "ERROR：".$_FILES["files"]["error"]."<br>";
}else {
	try { 
		ICON($_FILES["file"]["tmp_name"],"upload/export.icon");
    	echo 'download link: upload/export.icon';
	} catch(Exception $e) {
		echo 'ERROR'; //err 
	}

}
?>
