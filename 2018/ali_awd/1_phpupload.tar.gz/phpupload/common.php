<?php

function ICON($source_file, $dest_file){

	$thu= new Imagick();
	$thu->readImage($source_file);
	$thu->writeImage($dest_file);
	$thu->clear();
	$thu->destroy();
	unlink($source_file);
}

//check_upload_vul(){ }
