#!/usr/bin/env python
#-*-coding:utf-8 -*-


from flask import Flask, render_template,render_template_string, jsonify, url_for, request
from flask_jsglue import JSGlue
import random
from uuid import uuid1

app = Flask(__name__)
app.config['APPLICATION_ROOT']='/sample'
jsglue = JSGlue()
jsglue.init_app(app)  # 让js文件中可以使用url_for方法
results = []
chars = 'ABCDEFGHIJKLMNOPQRSTUVWSYZ'
results.append({'name': 'Copy from github', 'flag': 'true', 'index': str(uuid1())})
results.append({'name': '测试数据', 'flag': 'true', 'url': 'https://www.taobao.com', 'index': str(uuid1())})


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/sign_in')
def sign_in():
    if request.args.get('user'):
        template= "<h2>Wellcome %s!</h2>" % (request.args.get('user'))
        return render_template_string(template), 200
    else:
        return "illegally Access"

@app.route('/get_data')
def get_base_data():
    return jsonify({'results': results})


@app.route('/add', methods=['POST'])
def add():
    name = request.json.get('name')
    results.append({'name': name, 'index': str(uuid1())}) 
    return jsonify({'message': '添加成功！'}), 200


@app.route('/update', methods=['PUT'])
def update():
    name = request.json.get('name')
    index = request.json.get('index')
    for item in results:
        if item['index'] == index:
            item['name'] = name
            break
    return jsonify({'message': '编辑成功！'}), 200


@app.route('/delete', methods=['DELETE'])
def delete():
    name = request.args.get('name')
    index = request.args.get('index')
    results.remove({'name': name, 'index': index})
    return jsonify({'message': '删除成功！'}), 200


if __name__ == '__main__':
    app.run(debug=False)
