#!/bin/bash
# 2013-05-22 guoding.zh
# uwsgi init script
# unset PYTHONPATH

# Source function library.
. /etc/rc.d/init.d/functions

# **************************
prog=flask
base_dir=/home/admin/html/Vue-flask
conf=$base_dir/uwsgi.ini
# **************************
pidfile=`sed -rn 's/^pidfile\s*=\s*(.+)$/\1/p' $conf`

cd $base_dir
# ***************************

if [ ! -d $base_dir/logs ]; then
    mkdir -p $base_dir/logs
fi

start() {
    echo -n "Start $prog: "
    if [ -f $pidfile ]; then
        pid=`cat $pidfile`
        /usr/bin/pgrep -P $pid >/dev/null
        RETVAL=$?
        if [ $RETVAL -eq 0 ]; then
            action "" /bin/false
            echo "$prog already running(pid: $pid)"
            return 1
        fi
    fi

    uwsgi --ini $conf >$base_dir/logs/out.log 2>&1
    sleep 3
    if [ -f $pidfile ]; then
        pid=`cat $pidfile`
        action "" /bin/true
        return 0
    fi
    action "" /bin/false
    return 1
}

stop() {
    echo -n "Stop $prog: "
    if [ -f $pidfile ]; then
        pid=`cat $pidfile`
        /usr/bin/pgrep -P $pid >/dev/null
        RETVAL=$?
        if [ $RETVAL -eq 0 ]; then
            uwsgi --stop $pidfile
            sleep 3
            /usr/bin/pgrep -P $pid >/dev/null
            RETVAL=$?
            if [ $RETVAL -eq 0 ]; then
                action "" /bin/false
                return 1
            else
                action "" /bin/true
                return 0
            fi
        fi
    fi

    action "" /bin/false
    echo "$prog($conf) is not running?"
    return 1
}


status() {
    echo "Status for $prog..."
    if [ -f $pidfile ]; then
        pid=`cat $pidfile`
        /usr/bin/pgrep -P $pid >/dev/null
        RETVAL=$?
        if [ $RETVAL -eq 0 ]; then
            echo "$prog already running(pid: $pid)"
            return 0
        fi
    fi
    echo "$prog($conf) is not running?"
}

case "$1" in
    start) start;;
    stop) stop;;
    restart) stop;sleep 2;start;;
    status) status;;
    *) echo "Usage $0 (start|stop|restart|status)";;
esac
