const ROOT_PATH = __dirname

module.exports = {
  ROOT_PATH
}