<?php

$flag = "flag{4c6bcb25-40fb-4eef-b710-387660490b3a}";
exit(0);